# People Blockchain — Key facts (promoter pack, DRAFT)

Use these exact facts. Do not add numbers, partners, dates, prices or income claims.

**One line:** The blockchain where every user is a verified human. Owned by people, not VCs.

- **For ordinary people.** Launch a token, mint NFT club cards or raise money for an idea — with a form, no code.
- **Verified humans, not bots.** Rewards only for people who pass a free check: Telegram phone or Human Passport. Sign-up alone earns 0.
- **10% to the community.** Every launched token sends 10% of its supply to that token's own community pool.
- **Supply:** 1,000,000,000 PPL, fixed.
- **Allocation:** Community & rewards 35% · Validators & staking 20% · Team & founders 15% · Ecosystem treasury (DAO) 15% · Community sale 10% · Liquidity 5%.
- **Network fees:** validators 30% · community pool 25% · treasury 20% · liquidity 10% · Growth Pool 15% · burn 0%. Treasury and liquidity shares fund public PPL buybacks.
- **Token-launch fee:** payable in USDC/USDT or PPL.
- **Team:** small, anonymous, self-funded. No VC. No investor allocations. Team share (15% of supply) vests: 0% at launch, 6-month cliff, then 18 months linear (24 months total).
- **Million Founders:** points for invitees' real actions after verification — not sign-ups. PPL per point = season pool ÷ all points. Season 1 pool: 6,000,000 PPL. Paid 10% at once + the rest over 52 weeks.
- **Network:** public testnet on Cosmos EVM, chain `people_97401-1` (EVM chain id 97401). Not mainnet yet.
- **Roadmap:** Season 0 public testnet → mainnet and PPL sale after 1,000 verified people + a treasury multisig → staking and validators.
- **Security:** a security audit before mainnet; the treasury will be held in a multisig before mainnet.

**Always add:** Preliminary. Not a promise of income. Testnet tokens have no value.

**Never say:** "guaranteed", "profit", "APR", "yield", "x100", "investment", "independent audit", "partnered with …", any sale date or price.
