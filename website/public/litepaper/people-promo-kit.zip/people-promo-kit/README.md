# People Blockchain — Promoter pack

| File | What |
|---|---|
| ../promo-kit.pdf | One-page promo sheet (A4) |
| key-facts.md | The only facts to use, plus words to avoid |
| faq.md | Answers to "investors? team? when is the sale?" and more |
| links.md | Official links |
| logos/ | Official logos from the website's public brand assets (`website/public/brand`, `website/public/tokens/ppl.png`). `*-dark*` = white wordmark for dark backgrounds, `*-light*` = dark wordmark for light backgrounds, `full` = with "People's Blockchain" line, `icon-*` = symbol only, `ppl.png` = PPL coin |
| banners/banner-1200x675.png | X / Telegram / YouTube community post |
| banners/banner-1080x1080.png | Square post (Instagram, Telegram) |

Rules: don't edit logos, don't add faces, don't add numbers, dates, prices or partner names, and always keep "Preliminary · Not a promise of income".
