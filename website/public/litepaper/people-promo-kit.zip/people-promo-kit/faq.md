# People Blockchain — Promoter FAQ (DRAFT)

**Who are the investors?**
There are none. People is self-funded by a small team. No VC money, no investor allocations, no private round.

**Who is the team?**
A small, anonymous team. We publish our work, code and rules, not faces. The team's share (15% of supply) vests: 0% at launch, 6-month cliff, then 18 months linear (24 months total).

**When is the sale?**
There is no date. The PPL sale opens with mainnet, and only after two gates are met: at least 1,000 verified people and a live treasury multisig. It will be announced only on the official channels below. Anyone offering PPL before that is not us.

**Is this a promise of income?**
No. Points and PPL are not an investment. Prices can go up, down or to zero. No activity, no rewards.

**How do Million Founders points work?**
You earn points when the people you invite verify and do real actions on the network (swap, pool, NFT mint, token launch, vote) — not for sign-ups. At the end of a season, PPL per point = season pool ÷ all points. Season 1 pool: 6,000,000 PPL, paid 10% at once and the rest over 52 weeks. All preliminary.

**How do I verify?**
Free, once: share your phone in the official Telegram bot, or verify with Human Passport.

**Is it mainnet?**
No. It is a public testnet. Testnet tokens have no value.

**Where do fees go?**
Validators 30%, community pool 25%, treasury 20%, liquidity 10%, Growth Pool 15%, burn 0%. The treasury and liquidity shares fund public PPL buybacks.

**Is it safe?**
Contracts will go through a security audit before mainnet, and the treasury will be held in a multisig before mainnet. No software is risk-free.
